<?php

  session_start();
  session_destroy();

  $dados = array(
    "type" => "Success",
    "mensege" => "Sessão finalizada !"
  );

   echo json_encode($dados);